#!/bin/bash
remhost="10.1.10.20" # Change to remote host ip!
#bash setup.sh $remhost
bash run.sh $remhost
bash backup.sh $remhost

#!/bin/bash
cat README.md

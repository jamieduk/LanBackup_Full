#!/bin/bash
#
#  ./backup.sh 192.168.1.30
#
#
echo "Welcome To LanBackup 2020 By J~Net"
#
remote_location="Linux_Kali_Docs_Backup"
defaultip="192.168.1.30"
if [ "$#" -eq  "0" ]
  then
    read -p "Enter Remote IP [$defaultip]: " ip
        if [ -z "$ip" ]
     then
     ip=$defaultip
     fi
else
    ip=$1
fi
#
# $ cp -R <source_folder> <destination_folder>
echo "Type YES To Continue Backup... "
read proceed
if [ $proceed == 'YES' ] || [  $proceed == 'yes'  ]
then
    echo "Ok here we go, Please wait..."
    yes | sudo cp -Rnf /mnt/docs_backup/Docs/* /home/$USER/Documents/
    sudo chown -R $USER/home/$USER/Documents/
else
    echo "Error!"
fi
echo "All Done!"
